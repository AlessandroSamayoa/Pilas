﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pilas
{
    class pilas
    {
        
        int Max = 8;
        char[] pila = new char[10];
        int top = -1;

        public bool isEmpty()
        {
            if (top == -1)
                return true;
            else
                return false;
        }

        public bool isFull()
        {
            if (top == Max)
                return true;
            else
                return false;
        }

        public char peek()
        {
            return pila[top];
        }

        public char pop()
        {
            char value;

            if (!isEmpty()) 
            {
                value = pila[top];
                top = top - 1;
                return value;
                
            }
            else
            {
                Console.WriteLine("No se encuentra valor, pila vacia.\n");
                return '0';
            }
        }

        public char push(char value)
        {
            if(!isFull())
            {
                top = top + 1;
                pila[top] = value;
                return '1';
            }
            else
            {
                Console.WriteLine("La pila esta llena, no puede insertar más datos.\n");
                return '0';
            }
        }

        
           
        
    }
}
