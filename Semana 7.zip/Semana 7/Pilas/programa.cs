﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pilas
{
    class programa
    {
        static void Main(string[] args)
        {
            pilas uno = new pilas();
           // push items on to the stack 
            uno.push('h');
            uno.push('L');
            uno.push('x');
            uno.push('d');
            uno.push('f');
            uno.push('k');

            Console.WriteLine("El elemento al final de la pila era: {0}\n", uno.peek());
            Console.WriteLine("Elementos de la pila son: \n");
            uno.pop();
            // print stack data 
            while (!uno.isEmpty())
            {
                char data = uno.pop();
                Console.WriteLine("{0}\n", data);
            }

            
            Console.ReadLine();

            
        
        }
    }
}
